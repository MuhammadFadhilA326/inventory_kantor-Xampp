<?php
include 'db_connect.php';

header('Content-Type: application/json');

// Tambah data
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    $kode_barang = $conn->real_escape_string($_POST['kode_barang']);
    $nama_barang = $conn->real_escape_string($_POST['nama_barang']);
    $jumlah = (int)$_POST['jumlah'];
    $lokasi = $conn->real_escape_string($_POST['lokasi']);
    $kondisi = $conn->real_escape_string($_POST['kondisi']);

    $check_sql = "SELECT kode_barang FROM aset WHERE kode_barang = '$kode_barang'";
    $check_result = $conn->query($check_sql);

    if ($check_result->num_rows > 0) {
        echo json_encode(['status' => 'error', 'message' => 'Kode Barang sudah ada!']);
        exit;
    }

    $sql = "INSERT INTO aset (kode_barang, nama_barang, jumlah, lokasi, kondisi) VALUES ('$kode_barang', '$nama_barang', $jumlah, '$lokasi', '$kondisi')";
    if ($conn->query($sql) === TRUE) {
        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error', 'message' => $conn->error]);
    }
    exit;
}

// Hapus data
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    $kode_barang = $conn->real_escape_string($_POST['kode_barang']);
    $sql = "DELETE FROM aset WHERE kode_barang = '$kode_barang'";
    $conn->query($sql);
    echo json_encode(['status' => 'success']);
    exit;
}

// Ambil data dengan pencarian
$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
$sql = "SELECT kode_barang, nama_barang, jumlah, lokasi, kondisi FROM aset";
if (!empty($search)) {
    $sql .= " WHERE kode_barang LIKE '%$search%' 
              OR nama_barang LIKE '%$search%' 
              OR lokasi LIKE '%$search%' 
              OR kondisi LIKE '%$search%'";
}
$result = $conn->query($sql);

$inventory = [];
while ($row = $result->fetch_assoc()) {
    $inventory[] = $row;
}

echo json_encode($inventory);

$conn->close();
?>