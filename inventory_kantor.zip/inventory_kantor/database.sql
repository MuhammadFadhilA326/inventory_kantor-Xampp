CREATE DATABASE IF NOT EXISTS inventory_kantor;
USE inventory_kantor;

CREATE TABLE aset (
    kode_barang VARCHAR(50) PRIMARY KEY,
    nama_barang VARCHAR(100) NOT NULL,
    jumlah INT NOT NULL,
    lokasi VARCHAR(100) NOT NULL,
    kondisi VARCHAR(50) NOT NULL
);

INSERT INTO aset (kode_barang, nama_barang, jumlah, lokasi, kondisi) VALUES
('INV001', 'Laptop Dell', 5, 'Ruang IT', 'Baik'),
('INV002', 'Printer HP', 3, 'Ruang Admin', 'Baik'),
('INV003', 'Meja Kantor', 10, 'Ruang Kerja', 'Baik');