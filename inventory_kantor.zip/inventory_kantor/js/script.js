function loadInventory() {
    const searchTerm = document.getElementById('searchInput').value;
    fetch(`php/inventory.php?search=${encodeURIComponent(searchTerm)}`)
        .then(response => response.json())
        .then(data => {
            const tbody = document.getElementById('tableBody');
            tbody.innerHTML = '';
            data.forEach(item => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${item.kode_barang}</td>
                    <td>${item.nama_barang}</td>
                    <td>${item.jumlah}</td>
                    <td>${item.lokasi}</td>
                    <td>${item.kondisi}</td>
                    <td><button class="delete-btn" onclick="deleteItem('${item.kode_barang}')">Hapus</button></td>
                `;
                tbody.appendChild(row);
            });
        });
}

function addItem() {
    const kode_barang = document.getElementById('kode_barang').value;
    const nama_barang = document.getElementById('nama_barang').value;
    const jumlah = document.getElementById('jumlah').value;
    const lokasi = document.getElementById('lokasi').value;
    const kondisi = document.getElementById('kondisi').value;

    if (!kode_barang || !nama_barang || !jumlah || !lokasi || !kondisi) {
        alert('Semua kolom harus diisi!');
        return;
    }

    fetch('php/inventory.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `action=add&kode_barang=${kode_barang}&nama_barang=${nama_barang}&jumlah=${jumlah}&lokasi=${lokasi}&kondisi=${kondisi}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            alert('Barang berhasil ditambahkan!');
            document.getElementById('kode_barang').value = '';
            document.getElementById('nama_barang').value = '';
            document.getElementById('jumlah').value = '';
            document.getElementById('lokasi').value = '';
            document.getElementById('kondisi').value = 'Baik';
            loadInventory();
        } else {
            alert('Gagal menambahkan barang: ' + data.message);
        }
    });
}

function deleteItem(kode_barang) {
    if (confirm('Yakin ingin menghapus item ini?')) {
        fetch('php/inventory.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `action=delete&kode_barang=${kode_barang}`
        }).then(() => loadInventory());
    }
}

document.getElementById('searchInput').addEventListener('input', loadInventory);

window.onload = loadInventory;